<?php
include('koneksi.php');

if (isset($_SESSION['login_user'])) {
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Sistem Pakar</title>
  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js">

  <!-- Custom CSS -->
  <link rel="stylesheet" href="css/style.css">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Jost:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
</head>

<body class="index-page">

  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center">
      <a href="index.php" class="logo d-flex align-items-center me-auto">
        <h1 class="sitename">Tera</h1>
      </a>
      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="index.php" class="active">Home</a></li>
          <li><a href="#team">Our Team</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="daftargangguan.php">Daftar Gangguan</a></li>
          <li><button type="button" class="btn-getstarted" id="myBtn">Login as admin</button></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>
    </div>
  </header>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px; align-items: center;">
        <div class="modal-title" style="align-items: center;">Login</div>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>    
        </div>
        <div class="modal-body" style="padding:40px 50px;">
          <form role="form" method="post" action="ceklogin.php">
            <div class="form-group" method="post">
              <label for="username"> Username</label>
              <input type="text" class="form-control" name="username" id="password" placeholder="Enter username">
            </div>
            <div class="form-group" method="post">
              <br>
              <label for="password"><span class="glyphicon glyphicon-eye-open"></span> Password</label>
              <input type="password" class="form-control" name="password" id="password" placeholder="Enter password">
            </div>
              <br>
              <button style="margin: 0 auto; display: block;" type="submit" id="submit" nama="submit" class="btn btn-primary btn-block" method="post">Login</button>
          </form>
        </div>
      </div>
    </div>
</div> 

  <main class="main">
    <!-- Hero Section -->
    <section id="hero" class="hero section dark-background">
      <div class="container">
        <div class="row gy-4">
          <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center" data-aos="zoom-out">
            <h1>Sistem Pakar Jaringan Komputer</h1>
            <p>Ayoo deteksi kerusakan jaringan komputer anda!</p>
            <div class="d-flex">
              <a href="diagnosa.php" class="btn-get-started">Mulai Diagnosa!</a>
            </div>
          </div>
          <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-out" data-aos-delay="200">
            <img src="assets/img/hero-img.png" class="img-fluid animated" alt="">
          </div>
        </div>
      </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about section">
      <div class="container section-title" data-aos="fade-up">
        <h2>About System</h2>
      </div>
      <div class="container">
        <div class="row gy-4">
          <!-- <div class="col-lg-6 content" data-aos="fade-up" data-aos-delay="100"> -->
          <div>
            <center><h6>Jaringan komputer adalah salah satu infrastruktur penting dalam berbagai bidang, termasuk bisnis, pendidikan, dan pemerintahan. Namun, sering kali jaringan komputer mengalami gangguan atau kerusakan yang berdampak pada produktivitas. Kerusakan ini bisa disebabkan oleh berbagai faktor, seperti kesalahan konfigurasi, perangkat keras yang rusak, serangan malware, atau gangguan dari luar. Sering kali, para pengguna atau teknisi yang minim pengetahuan tentang jaringan komputer kesulitan mendiagnosis masalah yang terjadi, terutama jika ahli jaringan komputer tidak selalu tersedia untuk memberikan solusi secara cepat.</h6></center>

            <center><h6>Untuk mengatasi masalah ini, diperlukan sistem pakar yang mampu mendiagnosis kerusakan pada jaringan komputer. Sistem pakar kerusakan jaringan komputer bertujuan untuk membantu pengguna atau teknisi dalam mengidentifikasi masalah dan memberikan solusi yang tepat. Sistem ini dapat digunakan sebagai alat bantu konsultasi dan pelatihan di berbagai instansi, serta dapat menjadi sumber informasi untuk mensosialisasikan cara-cara penanganan kerusakan jaringan komputer yang sering terjadi. Dengan adanya sistem pakar ini, diharapkan para pengguna dapat dengan mudah mendiagnosis kerusakan jaringan tanpa harus bergantung sepenuhnya pada ahli, sehingga downtime jaringan dapat diminimalisir.</h6></center>
          </div>
        </div>
      </div>
    </section>

    <!-- Services Section
    <section id="services" class="services section light-background">
      <div class="container section-title" data-aos="fade-up">
        <h2>Daftar Gangguan</h2>
        <p>Necessitatibus eius consequatur ex aliquid fuga eum quidem sint consectetur velit</p>
      </div>
      <div class="container">
        <div class="row gy-4">
          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="100">
            <div class="service-item position-relative">
              <div class="icon"><i class="bi bi-activity icon"></i></div>
              <h4><a href="" class="stretched-link">Lorem Ipsum</a></h4>
              <p>Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi</p>
            </div>
          </div>
          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="200">
            <div class="service-item position-relative">
              <div class="icon"><i class="bi bi-bounding-box-circles icon"></i></div>
              <h4><a href="" class="stretched-link">Sed ut perspici</a></h4>
              <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore</p>
            </div>
          </div>
          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="300">
            <div class="service-item position-relative">
              <div class="icon"><i class="bi bi-calendar4-week icon"></i></div>
              <h4><a href="" class="stretched-link">Magni Dolores</a></h4>
              <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia</p>
            </div>
          </div>
          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="400">
            <div class="service-item position-relative">
              <div class="icon"><i class="bi bi-broadcast icon"></i></div>
              <h4><a href="" class="stretched-link">Nemo Enim</a></h4>
              <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis</p>
            </div>
          </div>
        </div>
      </div>
    </section> -->

    <!-- Call To Action Section -->
    <section id="call-to-action" class="call-to-action section dark-background">
      <img src="assets/img/pxfuel.jpg" alt="">
    </section>

    <!-- Team Section -->
    <section id="team" class="team section">
      <div class="container section-title" data-aos="fade-up">
        <h2>Team</h2>
        <p>Team ini terdiri dari 4 mahasiswa dari kelas 5B Program Studi Teknologi Informasi UIN Walisongo Semarang.  </p>
      </div>
      <div class="container">
        <div class="row gy-4">
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <div class="team-member d-flex align-items-start">
              <div class="pic"><img src="assets/img/team/team-1.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h3>Arfiana Diah Pramesti</h3>
                <span>Fronted Specialist</span>
                <p>Mahasiswa Teknologi Informasi UIN Walisongo Semarang</p>
                <div class="social">
                  <a href=""><i class="bi bi-twitter-x"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href="https://www.instagram.com/arvdhp?igsh=anFmYWV0MHRlZnJi"><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="200">
            <div class="team-member d-flex align-items-start">
              <div class="pic"><img src="assets/img/team/team-2.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h3>Fastabiqul Khusna</h3>
                <span>Process Data</span>
                <p>Mahasiswa Teknologi Informasi UIN Walisongo Semarang</p>
                <div class="social">
                  <a href=""><i class="bi bi-twitter-x"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href="https://www.instagram.com/fstbqlkhusna?igsh=N3VrbTQ4aXlqaHR6"><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="300">
            <div class="team-member d-flex align-items-start">
              <div class="pic"><img src="assets/img/team/tim-3.png" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h3>Ananda Akbar Maulana</h3>
                <span>Backend Specialist</span>
                <p>Mahasiswa Teknologi Informasi UIN Walisongo Semarang</p>
                <div class="social">
                  <a href=""><i class="bi bi-twitter-x"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href="https://www.instagram.com/ananda_akbr?igsh=aDduZXk0a3M4MzZ3"><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="400">
            <div class="team-member d-flex align-items-start">
              <div class="pic"><img src="assets/img/team/tim-4.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h3>Muhammad Sidqi</h3>
                <span>Leader</span>
                <p>Mahasiswa Teknologi Informasi UIN Walisongo Semarang</p>
                <div class="social">
                  <a href=""><i class="bi bi-twitter-x"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href="https://www.instagram.com/sidqialkathiri?igsh=MTAyM2pvem5vOTA5YQ=="><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer id="footer" class="footer">
    <div class="container copyright text-center mt-4">
      <p>© <span>Copyright</span> <strong class="px-1 sitename">Tera</strong> <span>All Rights Reserved</span></p>
      <div class="credits">
        Designed by <a href="https://bootstrapmade.com/">Teknologi Informasi UIN Walisongo Semarang</a>
      </div>
    </div>
  </footer>

  <!-- Custom JavaScript -->
  <script>
    $(document).ready(function(){
      $("#myBtn").click(function(){
        $("#myModal").modal('show');
      });
    });
  </script>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>
</html>
