<?php
include('koneksi.php');
 
if(isset($_SESSION['login_user'])){

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Pakar</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js">

  <!-- Custom CSS -->
  <link rel="stylesheet" href="css/style.css">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Jost:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
</head>

<section class="section">
  <header id="header" class="header d-flex align-items-center fixed-top">
      <div class="container-fluid container-xl position-relative d-flex align-items-center">
        <a href="index.php" class="logo d-flex align-items-center me-auto">
        <h1 class="sitename">Tera</h1>
      </a>
      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="index.php" class="active">Home</a></li>
          <li><a href="daftargangguan.php">Daftar Gangguan</a></li>
          <li><button type="button" class="btn-getstarted" id="myBtn">Login as admin</button></li>
        </ul>
          <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>
      </div>
    </header>  
</section>
<div class="card">
    <div class="card-body">
    <center><h1>DETAIL GANGGUAN</h1></center></div>
    <div class="card">
    <div class="card-body">
      <div class="form-group"  method="POST">
      			<br><label class="control-label col-sm">KODE GANGGUAN :</label>
      		<div class="col-sm">
                <?php
                       $tampil = "SELECT * FROM gangguan where idgangguan='".$_GET['idgangguan']."'";
                       $sql = mysqli_query ($konek_db,$tampil);
                       while($data = mysqli_fetch_array ($sql))
                    {
                       echo "<input type='text'  class='form-control' id='idgangguan' disabled value='".$data['idgangguan']."'><br>";
                    }
                ?>
     		 </div>
        </div>	
        <div class="form-group"  method="POST">
      			<br><label class="control-label col-sm">NAMA GANGGUAN :</label>
      		<div class="col-sm">
                <?php
                       $tampil = "SELECT * FROM gangguan where idgangguan='".$_GET['idgangguan']."'";
                       $sql = mysqli_query ($konek_db,$tampil);
                       while($data = mysqli_fetch_array ($sql))
                    {
                       echo "<input type='text'  class='form-control' id='gangguan' disabled value='".$data['gangguan']."'><br>";
                    }
                ?>
     		 </div>
        </div>
        <div class="form-group"  method="POST">
      			<br><label class="control-label col-sm">SOLUSI :</label>
      		<div class="col-sm">
                <?php
                       $tampil = "SELECT * FROM gangguan where idgangguan='".$_GET['idgangguan']."'";
                       $sql = mysqli_query ($konek_db,$tampil);
                       while ($data = mysqli_fetch_array($sql)) {
                        $solusi_array = explode('-', $data['solusi']);
                        foreach ($solusi_array as $no => $solusi) {
                          echo "<ul class='form-control'>".($no+1) . '. ' . $solusi."</ul>";
                        }}
                        ?>
     		 </div>
        </div>	
         <div class="form-group"  method="POST">
      			<br><label class="control-label col-sm">GEJALA :</label>
      		<div class="col-sm">
                <?php
                       $result = mysqli_query($konek_db, "SELECT ba.idaturan, ba.idgangguan, COALESCE(GROUP_CONCAT(CONCAT(db.idgejala, ' - ', gejala.gejala) SEPARATOR '<br>'), 'Tidak ada gejala') AS gejala_detail
                       FROM basis_aturan ba INNER JOIN detail_basis_aturan db 
                       ON ba.idaturan = db.idaturan LEFT JOIN gejala ON db.idgejala = gejala.idgejala
                       WHERE ba.idgangguan = '".$_GET['idgangguan']."'");

                    while($row = $result->fetch_assoc()) {
                      $gejala = $row['gejala_detail'];
                      if (empty($gejala)) {
                        echo "<input type='text' class='form-control' id='gejala' disabled value='Tidak Ada Gejala'><br>";}
                        echo "<ul class='form-control'>" . $row['gejala_detail'] . "</ul><br>";
                    }
                ?>
     		 </div>
        </div>	
        </div>	
        </div>	
  </div>
</div>

 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4><span class="glyphicon glyphicon-lock"></span> Login</h4>
        </div>
        <div class="modal-body" style="padding:40px 50px;">
         <form role="form" method="post" action="ceklogin.php">
            <div class="form-group" method="post">
              <label for="username"><span class="glyphicon glyphicon-user"></span> Username</label>
              <input type="text" class="form-control" name="username" id="password" placeholder="Enter username">
            </div>
            <div class="form-group" method="post">
              <label for="password"><span class="glyphicon glyphicon-eye-open"></span> Password</label>
              <input type="password" class="form-control" name="password" id="password" placeholder="Enter password">
            </div>
              <button type="submit" id="submit" nama="submit" class="btn btn-primary btn-block" method="post"><span class="glyphicon glyphicon-off"></span> Login</button>
          </form>
        </div>
      </div>
    </div>
  </div> 

  <footer class="footer">
    <div class="container copyright text-center mt-4">
      <p>© <span>Copyright</span> <strong class="px-1 sitename">Tera</strong> <span>All Rights Reserved</span></p>
      <div class="credits">
        Designed by <a href="https://bootstrapmade.com/">Teknologi Informasi UIN Walisongo Semarang</a>
      </div>
    </div>
</footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

<script>
$(document).ready(function(){
    $("#myBtn").click(function(){
        $("#myModal").modal();
    });
});
</script>

</body>
</html>
