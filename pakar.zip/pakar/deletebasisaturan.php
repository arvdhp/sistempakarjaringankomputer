<?php
    $idaturan=$_GET['idaturan'];
    include('koneksi.php');
    $sql1 = "DELETE FROM basis_aturan WHERE idaturan='$idaturan'";
    $sql2 = "DELETE FROM detail_basis_aturan WHERE idaturan='$idaturan'";
    mysqli_query($konek_db, $sql1);    
    mysqli_query($konek_db, $sql2);   
    header("Location:basisaturan.php");
?>