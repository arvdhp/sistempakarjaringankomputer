-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 14, 2024 at 05:43 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sbp`
--

-- --------------------------------------------------------

--
-- Table structure for table `basis_aturan`
--

CREATE TABLE `basis_aturan` (
  `idaturan` int(10) NOT NULL,
  `idgangguan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `basis_aturan`
--

INSERT INTO `basis_aturan` (`idaturan`, `idgangguan`) VALUES
(1, 'PG01'),
(2, 'PG02'),
(3, 'PG03'),
(4, 'PG04'),
(5, 'PG05'),
(6, 'PG06'),
(7, 'PG07'),
(8, 'PG08'),
(9, 'PG09'),
(10, 'PG10'),
(11, 'PG11'),
(12, 'PG12'),
(13, 'PG13'),
(14, 'PG14'),
(15, 'PG15'),
(16, 'PG16'),
(17, 'PG17'),
(18, 'PG18');

-- --------------------------------------------------------

--
-- Table structure for table `detail_basis_aturan`
--

CREATE TABLE `detail_basis_aturan` (
  `idaturan` int(10) NOT NULL,
  `idgejala` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detail_basis_aturan`
--

INSERT INTO `detail_basis_aturan` (`idaturan`, `idgejala`) VALUES
(1, 'GG01'),
(1, 'GG03'),
(1, 'GG04'),
(1, 'GG02'),
(2, 'GG01'),
(2, 'GG02'),
(3, 'GG01'),
(3, 'GG04'),
(3, 'GG02'),
(4, 'GG18'),
(4, 'GG01'),
(4, 'GG23'),
(4, 'GG22'),
(4, 'GG02'),
(5, 'GG01'),
(5, 'GG08'),
(5, 'GG06'),
(6, 'GG18'),
(6, 'GG01'),
(6, 'GG19'),
(6, 'GG20'),
(6, 'GG06'),
(7, 'GG01'),
(7, 'GG08'),
(7, 'GG06'),
(8, 'GG01'),
(8, 'GG06'),
(9, 'GG29'),
(9, 'GG30'),
(9, 'GG31'),
(9, 'GG21'),
(10, 'GG18'),
(10, 'GG25'),
(10, 'GG26'),
(10, 'GG24'),
(10, 'GG11'),
(11, 'GG13'),
(11, 'GG12'),
(11, 'GG11'),
(12, 'GG14'),
(12, 'GG11'),
(13, 'GG29'),
(13, 'GG35'),
(13, 'GG34'),
(14, 'GG09'),
(14, 'GG10'),
(14, 'GG06'),
(15, 'GG18'),
(15, 'GG09'),
(15, 'GG16'),
(15, 'GG15'),
(15, 'GG17'),
(16, 'GG09'),
(16, 'GG28'),
(16, 'GG16'),
(16, 'GG27'),
(17, 'GG29'),
(17, 'GG30'),
(17, 'GG32'),
(17, 'GG21'),
(18, 'GG01'),
(18, 'GG33');

-- --------------------------------------------------------

--
-- Table structure for table `gangguan`
--

CREATE TABLE `gangguan` (
  `nomor` int(10) NOT NULL,
  `idgangguan` varchar(10) NOT NULL,
  `gangguan` mediumtext NOT NULL,
  `solusi` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gangguan`
--

INSERT INTO `gangguan` (`nomor`, `idgangguan`, `gangguan`, `solusi`) VALUES
(1, 'PG01', 'Kabel Fiber Optic Rusak/Bermasalah', 'Periksa Koneksi: Pastikan semua konektor terpasang dengan baik-Gunakan OTDR: Uji kabel untuk menemukan lokasi kerusakan-Pemeriksaan Visual: Cek kabel fisik untuk kerusakan visual-Ganti Konektor: Ganti konektor yang rusak-Splicing atau Ganti Kabel: Lakukan penyambungan atau ganti kabel jika perlu-Hubungi Profesional: Jika masalah berlanjut, minta bantuan teknisi berpengalaman.'),
(2, 'PG02', 'Router Distribusi Mati/Bermasalah', 'Periksa Koneksi Kabel: Periksa kabel listrik, stop kontak, dan sumber listrik utama untuk memastikan tidak ada kerusakan. - Overheating: Pastikan router memiliki ventilasi yang baik dan tidak diletakkan di tempat yang terlalu panas. - Konfigurasi Salah: Periksa pengaturan IP, DNS, dan konfigurasi lainnya, serta lakukan pemindaian virus. - Kerusakan Hardware: Jika masalah berlanjut setelah mencoba solusi lain, kemungkinan ada komponen internal router yang rusak. - Restart Router: Mematikan dan menghidupkan kembali router dapat mengatasi masalah sementara pada koneksi.  - Reset Router: Mengembalikan pengaturan router ke awal dapat membantu mengatasi masalah konfigurasi.  -  Hubungi Penyedia Layanan Internet: Jika masalah masih berlanjut, kemungkinan ada masalah dengan koneksi internet dari penyedia layanan.'),
(3, 'PG03', 'Modem Mati/Rusak', 'Periksa Koneksi: Pastikan kabel dari modem ke komputer terhubung dengan baik dan tidak ada yang longgar. - Restart Modem: Matikan modem selama beberapa saat, lalu hidupkan kembali. - Cek Sumber Daya: Pastikan modem terhubung ke stop kontak yang berfungsi dengan baik. - Uji dengan Perangkat Lain: Coba hubungkan perangkat lain (misalnya laptop) ke modem untuk memastikan masalahnya bukan dari perangkat komputer. - Hubungi Provider: Jika masalah masih berlanjut, hubungi penyedia layanan internet Anda untuk melaporkan gangguan dan meminta bantuan teknis. - Ganti Modem: Jika modem sudah benar benar rusak, anda perlu menggantinya dengan yang baru'),
(4, 'PG04', 'Kabel LAN dari Modem ke Router Tidak Tersambung/Bermasalah', 'Cek fisik: Pastikan kabel terpasang erat, ganti kabel jika perlu, dan coba port lain. - Restart: Matikan dan hidupkan kembali modem dan router. - Pengaturan: Periksa pengaturan IP pada kedua perangkat. - Faktor lain: Cek kerusakan fisik kabel, hindari gangguan elektromagnetik. - Hubungi provider: Jika masalah berlanjut, hubungi penyedia layanan internet Anda.'),
(5, 'PG05', 'Router Mati/Rusak', 'Periksa Koneksi: Pastikan kabel listrik router terhubung dengan benar dan stop kontak berfungsi. - Restart Router: Matikan router selama beberapa saat, lalu hidupkan kembali. - Cek Lampu Indikator: Pastikan semua lampu indikator pada router menyala dengan normal. - Uji dengan Perangkat Lain: Coba hubungkan perangkat lain (misalnya laptop lain) ke router untuk memastikan masalahnya bukan pada perangkat Anda. - Hubungi Provider: Jika masalah masih berlanjut, hubungi penyedia layanan internet Anda untuk melaporkan gangguan. - Ganti Router: Jika router sudah rusak, pertimbangkan untuk menggantinya dengan yang baru'),
(6, 'PG06', 'Kabel LAN Dari Router ke Switch Tidak Tersambung/Bermasalah', 'Cek fisik: Pastikan kabel terpasang erat, ganti kabel, dan coba port lain. - Restart: Matikan dan hidupkan kembali router dan switch. - Pengaturan: Pastikan keduanya dalam jaringan yang sama. - Faktor lain: Cek kerusakan kabel, hindari gangguan. - Teknisi: Jika masih bermasalah, hubungi teknisi jaringan.'),
(7, 'PG07', 'Switch Mati/Rusak', 'Cek kabel: Pastikan terpasang erat, ganti jika perlu. - Restart: Matikan lalu hidupkan kembali. - Port: Coba port lain di router dan switch. -  Teknisi: Jika masih error, panggil teknisi.'),
(8, 'PG08', 'Perangkat Modem Router dan Switch Hang', 'Restart: Matikan semua perangkat, tunggu, lalu hidupkan lagi. - Listrik: Pastikan stop kontak berfungsi baik. - Koneksi: Hubungi provider internet Anda. - Suhu: Pastikan perangkat tidak terlalu panas. - Konfigurasi: Coba atur ulang ke pengaturan pabrik. - Kabel: Periksa semua kabel. - Firmware: Perbarui firmware jika ada. - Beban: Kurangi jumlah perangkat yang terhubung. - Teknisi: Jika masih bermasalah, panggil teknisi.'),
(9, 'PG09', 'Looping', 'Identifikasi: Temukan di mana loop terjadi menggunakan alat bantu jaringan. Periksa fisik: Pastikan semua kabel terpasang dengan benar. - Konfigurasi ulang: Periksa dan atur ulang pengaturan jaringan seperti VLAN dan STP. - Periksa perangkat: Pastikan semua perangkat berfungsi dengan baik. - Segmentasi jaringan: Bagi jaringan menjadi bagian bagian yang lebih kecil.'),
(10, 'PG10', 'Kabel LAN dari Switch ke Access Point Tidak Tersambung/Bermasalah', 'Cek fisik: Pastikan kabel terpasang kuat, tidak rusak, dan port berfungsi. - Konfigurasi: Periksa IP address, subnet mask, gateway, dan VLAN. - Perangkat: Restart, update firmware, atau cek kerusakan hardware. - Kabel: Ganti kabel atau gunakan tester kabel. - Log: Periksa log perangkat untuk pesan error.'),
(11, 'PG11', 'Perangkat Access Point Rusak/Mati', 'Cek fisik: Periksa kabel daya, tombol reset, dan lampu indikator. - Periksa: Jika terlalu panas, matikan dan biarkan dingin. - Update firmware: Perbarui firmware ke versi terbaru. - Konfigurasi: Periksa IP address, setting, dan konflik dengan perangkat lain. - Hubungi vendor: Jika masalah berlanjut, hubungi vendor untuk servis.'),
(12, 'PG12', 'Perangkat Access Point Hang', 'Restart: Matikan dan nyalakan kembali. - Cek daya: Pastikan kabel daya terhubung baik dan sumber listrik stabil. - Cek suhu: Jangan biarkan terlalu panas. - Update firmware: Perbarui ke versi terbaru. - Reset: Kembalikan ke pengaturan pabrik (jika perlu). - Cek koneksi: Pastikan kabel terhubung dengan baik. - Kurangi beban: Batasi jumlah perangkat yang terhubung. - Hindari interferensi: Jauhkan dari perangkat lain yang mengganggu sinyal. - Cek log: Cari pesan error di log perangkat.'),
(13, 'PG13', 'Collision', 'Gunakan switch: Ganti hub dengan switch untuk menghindari collision. - Cek kabel: Pastikan semua kabel terhubung dengan baik dan tidak rusak. - Konfigurasi ulang: Periksa pengaturan duplex dan kecepatan pada semua perangkat. - Kurangi beban: Batasi jumlah perangkat yang terhubung ke jaringan.'),
(14, 'PG14', 'HUB Mati/Rusak', 'Cek koneksi: Pastikan kabel dan daya terhubung dengan baik. - Ganti port: Coba pindahkan perangkat ke port lain. - Periksa lampu: Lihat apakah lampu indikator berfungsi normal. - Reset hub: Tekan tombol reset jika ada. - Ganti hub: Jika masalah berlanjut, ganti dengan yang baru.'),
(15, 'PG15', 'Kabel LAN dari HUB Ruangan ke Komputer Tidak Tersambung/Bermasalah', 'Cek fisik: Pastikan kabel terpasang kuat, tidak rusak, dan port berfungsi. - Cek pengaturan: Pastikan IP address, subnet mask, dan gateway sudah benar. - Cek driver: Pastikan driver kartu jaringan sudah update. - Ganti kabel: Coba gunakan kabel baru jika perlu. - Cek perangkat lain: Pastikan hub, router, dan switch berfungsi baik.'),
(16, 'PG16', 'LAN Card Komputer Rusak/Bermasalah', 'Cek fisik: Pastikan kabel terpasang kuat dan port berfungsi. - Cek driver: Update atau instal ulang driver kartu jaringan. - Cek pengaturan: Pastikan IP address, subnet mask, dan gateway sudah benar. - Cek hardware: Coba lepas pasang kartu jaringan (jika laptop). - Ganti kartu: Jika semua gagal, mungkin kartu jaringan rusak.'),
(17, 'PG17', 'Overload Bandwidth/Internet Limited Access', 'Restart perangkat: Router dan komputer. - Kurangi pengguna: Cabut perangkat yang tidak digunakan. - Batasi aktivitas: Hindari aktivitas berat seperti streaming atau download besar. - Cek koneksi: Pastikan kabel terhubung dengan baik. - Update perangkat lunak: Update firmware router dan driver. - Ubah saluran WiFi: Pilih saluran yang kurang ramai. - Hubungi ISP: Laporkan masalah ke penyedia layanan internet. - Cek konfigurasi router: Periksa pengaturan QoS.'),
(18, 'PG18', 'Gangguan Massal (GAMAS) di Seluruh OPD', 'Hubungi ISP: Laporkan masalah ke penyedia layanan internet Anda. - Restart perangkat: Router, modem, dan perangkat lain. - Cek koneksi: Pastikan kabel terhubung baik dan tidak rusak. - Update driver: Perbarui driver kartu jaringan. - Gunakan DNS publik: Coba Google DNS (8.8.8.8) atau Cloudflare DNS (1.1.1.1). - Cek konfigurasi: Pastikan pengaturan jaringan sudah benar.');

-- --------------------------------------------------------

--
-- Table structure for table `gejala`
--

CREATE TABLE `gejala` (
  `nomor` int(10) NOT NULL,
  `idgejala` varchar(10) NOT NULL,
  `gejala` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gejala`
--

INSERT INTO `gejala` (`nomor`, `idgejala`, `gejala`) VALUES
(1, 'GG01', 'Koneksi internet di OPD mati totall'),
(2, 'GG02', 'Tidak bisa melakukan ping ke router distribusi Diskominfotik'),
(3, 'GG03', 'Lampu indikator loss pada modem menyala'),
(4, 'GG04', 'Redaman Kabel Tinggi'),
(5, 'GG05', 'Lampu indikator power pada modem tidak menyala'),
(6, 'GG06', 'Tidak bisa melakukan ping ke router OPD'),
(7, 'GG07', 'Lampu indikator power pada router tidak menyala/menyala tidak normal'),
(8, 'GG08', 'Lampu indikator power pada switch tidak menyala/menyala tidak normal'),
(9, 'GG09', 'Komputer User tidak mendapatkan akses internet'),
(10, 'GG10', 'Lampu indikator power pada hub tidak menyala/menyala tidak normal'),
(11, 'GG11', 'Tidak mendapatkan akses internet ketika menggunakan perangkat access point'),
(12, 'GG12', 'SSID access point tidak terbaca oleh perangkat'),
(13, 'GG13', 'Lampu indikator power pada access point tidak menyala'),
(14, 'GG14', 'Perangkat access point tidak merespon'),
(15, 'GG15', 'Lampu Indikator port LAN di HUB ke Komputer tidak menyala'),
(16, 'GG16', 'Lampu indikator LAN card pada komputer tidak menyala'),
(17, 'GG17', 'Status pada network Connection adalah cable unplug'),
(18, 'GG18', 'Kabel LAN tidak terpasang dengan baik/rusak'),
(19, 'GG19', 'Lampu indikator port LAN pada router yang terhubung ke switch tidak menyala'),
(20, 'GG20', 'Lampu indikator port LAN pada switch yang terhubung ke router tidak menyala'),
(21, 'GG21', 'Tidak bisa melakukan ping ke router distribusi'),
(22, 'GG22', 'Lampu indikator port LAN pada router yang terhubung ke modem tidak menyala'),
(23, 'GG23', 'Lampu indikator port LAN pada modem yang terhubung ke router tidak menyala'),
(24, 'GG24', 'Status SSID pada Koneksi Access Point No internet/limited access'),
(25, 'GG25', 'Lampu indikator LAN pada perangkat access point tidak menyala'),
(26, 'GG26', 'Lampu indikator port LAN pada Switch yang terhubung ke Access Point tidak menyala'),
(27, 'GG27', 'Lampu indikator LAN card pada komputer tidak menyala'),
(28, 'GG28', 'Kondisi kabel LAN dari HUB ke komputer berfungsi dengan baik'),
(29, 'GG29', 'Koneksi Internet di OPD tidak stabil dan sangat lambat, Ping time/latency cenderung tinggi, trafik lambat'),
(30, 'GG30', 'Loading page lambat saat browsing'),
(31, 'GG31', 'Ping ke router OPD putus-putus'),
(32, 'GG32', 'Ping ke router Distribusi putus-putus'),
(33, 'GG33', 'Tidak bisa melakukan ping ke google atau 8.8.8.8 -t'),
(34, 'GG34', 'Perangkat tidak mendapatkan alokasi IP dinamis (DHCP) dari router OPD'),
(35, 'GG35', 'Perangkat dapat terhubung ke internet setelah dipasang IP statis');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `nama`) VALUES
('admin', 'admin', 'fifi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `basis_aturan`
--
ALTER TABLE `basis_aturan`
  ADD PRIMARY KEY (`idaturan`);

--
-- Indexes for table `gangguan`
--
ALTER TABLE `gangguan`
  ADD PRIMARY KEY (`idgangguan`);

--
-- Indexes for table `gejala`
--
ALTER TABLE `gejala`
  ADD PRIMARY KEY (`idgejala`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `basis_aturan`
--
ALTER TABLE `basis_aturan`
  MODIFY `idaturan` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
