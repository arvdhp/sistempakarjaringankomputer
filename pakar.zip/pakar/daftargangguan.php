<?php
include('koneksi.php');
 
$result = mysqli_query($konek_db, "SELECT * FROM gangguan");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Pakar</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js">

  <!-- Custom CSS -->
  <link rel="stylesheet" href="css/style.css">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Jost:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
</head>

<header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center">
      <a href="index.php" class="logo d-flex align-items-center me-auto">
        <h1 class="sitename">Tera</h1>
      </a>
      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="index.php" class="active">Home</a></li>
          <li><a href="daftargangguan.php">Daftar Gangguan</a></li>
          <li><button type="button" class="btn-getstarted" id="myBtn">Login as admin</button></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>
    </div>
  </header>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px; align-items: center;">
        <div class="modal-title" style="align-items: center;">Login</div>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>    
        </div>
        <div class="modal-body" style="padding:40px 50px;">
          <form role="form" method="post" action="ceklogin.php">
            <div class="form-group" method="post">
              <label for="username"> Username</label>
              <input type="text" class="form-control" name="username" id="password" placeholder="Enter username">
            </div>
            <div class="form-group" method="post">
              <br>
              <label for="password"><span class="glyphicon glyphicon-eye-open"></span> Password</label>
              <input type="password" class="form-control" name="password" id="password" placeholder="Enter password">
            </div>
              <br>
              <button style="margin: 0 auto; display: block;" type="submit" id="submit" nama="submit" class="btn btn-primary btn-block" method="post">Login</button>
          </form>
        </div>
      </div>
    </div>
</div> 

  <div class="page-header">
    <br><br><br><br><br>
  <center><h1>DAFTAR GANGGUAN</h1></center></div><br>
  <div class="card">
    <div class="card-body">
    <div class="table-responsive">
    <div class="card-body">
            <table class="table table-bordered table-hover table-striped">
                <thead>
                    <tr>
                      <th width="1px" ><center>No.</center></th>  
                      <th width="50px"><center>Kode Gangguan</center></th>
                      <th width="170px"><center>Nama Gangguan</center></th>
                      <th width="400px"><center>Solusi</center></th>
                      <th width="40px"><center>Aksi</center></th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    while ($data = mysqli_fetch_array($result)) {
                      $solusi_array = explode('-', $data['solusi']); // Pisahkan solusi menjadi array
                  ?>
                    <tr>
                        <td align="center"><?= $data['nomor'] ?></td> 
                        <td align="center"><?= $data['idgangguan'] ?></td>
                        <td><?= $data['gangguan'] ?></td>
                        <td align="justify">
                        <?php
                        foreach ($solusi_array as $no => $solusi) {
                            echo '<p>' . ($no+1) . '. ' . $solusi . '<p/>';
                        }
                        ?>
                        </td>
                        <td class="nw" align="center">
                        <a class="btn btn-sm btn-secondary" href="detailgangguan.php?idgangguan=<?= $data['idgangguan'] ?>">
                        Detail<i class="fas fa-edit fa-fw"></i>
                        </td>
                    </tr>
                    <?php
                      }
                    ?>
                </tbody>
            </table>
        </div>
      </div>
    </div>

  <footer id="footer" class="footer">
    <div class="container copyright text-center mt-4">
      <p>© <span>Copyright</span> <strong class="px-1 sitename">Tera</strong> <span>All Rights Reserved</span></p>
      <div class="credits">
        Designed by <a href="https://bootstrapmade.com/">Teknologi Informasi UIN Walisongo Semarang</a>
      </div>
    </div>
  </footer>

  <!-- Custom JavaScript -->
  <script>
    $(document).ready(function(){
      $("#myBtn").click(function(){
        $("#myModal").modal('show');
      });
    });
  </script>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>
</html>
