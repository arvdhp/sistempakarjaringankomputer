<?php
    include('koneksi.php');
    $query="DELETE from gangguan where idgangguan='".$_GET['idgangguan']."'";
    mysqli_query($konek_db, $query);
    header("location:gangguan.php");
?>