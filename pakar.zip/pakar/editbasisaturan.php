<?php
include('koneksi.php');
include "session.php";

if (isset($_SESSION['login_user'])) {
    // Simpan informasi pengguna yang sedang login jika diperlukan
}

// Proses penghapusan gejala jika parameter `action` adalah `hapus_gejala`
if (isset($_GET['action']) && $_GET['action'] == 'hapus_gejala') {
    $idaturan = $_GET['idaturan'];
    $idgejala = $_GET['idgejala'];

    // Query untuk menghapus gejala dari aturan terkait
    $sql_delete = "DELETE FROM detail_basis_aturan WHERE idaturan='$idaturan' AND idgejala='$idgejala'";

    if ($konek_db->query($sql_delete) === TRUE) {
        echo "<script>alert('Gejala berhasil dihapus!');</script>";
    } else {
        echo "<script>alert('Gagal menghapus gejala!');</script>";
    }

    // Redirect kembali ke halaman edit aturan
    echo "<script>window.location.href = 'editbasisaturan.php?idaturan=$idaturan';</script>";
    exit;
}

// Cek apakah `idaturan` ada dalam URL
$idaturan = $_GET['idaturan'] ?? '';

if ($idaturan) {
    $result = mysqli_query($konek_db, "SELECT basis_aturan.idaturan, basis_aturan.idgangguan, gangguan.gangguan 
        FROM basis_aturan 
        INNER JOIN gangguan ON basis_aturan.idgangguan = gangguan.idgangguan 
        WHERE basis_aturan.idaturan = '$idaturan'");

    $row = $result->fetch_assoc();

    if(isset($_POST['submit'])){
      if (isset($_POST['idgejala']) && !empty($_POST['idgejala'])) {
        $idgejala = $_POST['idgejala'];
        $jumlah = count($idgejala);
        $i = 0;
        while ($i < $jumlah) {
            $idgejalane = $idgejala[$i];
            $sql = "INSERT INTO detail_basis_aturan (idaturan, idgejala) VALUES ('$idaturan', '$idgejalane')";
            mysqli_query($konek_db, $sql);
            $i++;
        }
        // Redirect setelah sukses
        header("Location: editbasisaturan.php?idaturan=$idaturan");
        exit;
    } else {
        echo "<script>alert('Tidak ada gejala yang dipilih!');</script>";
    }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Pakar</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js">

  <!-- Custom CSS -->
  <link rel="stylesheet" href="css/style.css">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Jost:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
</head>

<body>
<section class="section">
  <header id="header" class="header d-flex align-items-center fixed-top">
      <div class="container-fluid container-xl position-relative d-flex align-items-center">
        <a href="homeadmin.php" class="logo d-flex align-items-center me-auto">
          <h1 class="sitename;">Tera</h1>      
        </a>
        <a class="logo d-flex me-auto">
        <h1 class="sitename;">Hi, <?php echo $login_session; ?>!</h1>
        </a>
        <nav id="navmenu" class="navmenu">
          <ul>
            <li><a href="homeadmin.php" class="active">Home Admin</a></li>
            <li><a href="gangguan.php">Gangguan</a></li>
            <li><a href="gejala.php">Gejala</a></li>
            <li><a href="basisaturan.php">Basis Aturan</a></li>
            <li><a href="logout.php"><button type="button" class="btn btn-getstarted" id="myBtn">LOGOUT</button></a></li>
          </ul>
          <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>
      </div>
    </header>  
</section>

<div class="page-header">
  <center><h1>EDIT BASIS ATURAN</h1></center><br>
  <div class="card">
    <div class="card-body">
      <form action="" method="POST">
        <div class="form-group">
          <div class="card-body">
            <label for="">Nama Gangguan :</label>
            <input type="text" class="form-control" value="<?php echo $row['gangguan'] ?>" name="gangguan" readonly>
          </div>
        </div>
        <div class="form-grup">
          <div class="card-body">
            <label for="">Pilih Gejala-Gejala Berikut :</label>
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th width="30px"></th>
                  <th width="30px">No.</th>
                  <th width="700px">Nama Gejala</th>
                  <th width="50px">Aksi</th>
                </tr>
              </thead>
                <tbody>
                  <?php
                    $no=1;
                    $sql = "SELECT * FROM gejala ORDER BY gejala ASC";
                    $result = $konek_db->query($sql);
                    while($row = $result->fetch_assoc()) {
                      $idgejala =$row['idgejala'];
                      $result2 = mysqli_query($konek_db, "SELECT * FROM detail_basis_aturan WHERE idaturan='$idaturan' AND idgejala='$idgejala'");
                      if ($result2->num_rows > 0) {                        
                  ?>
                  <tr>
                    <td align="center"><input type="checkbox" class="check-item" disabled="disabled"></td>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $row['gejala']; ?></td>
                    <td align="center">
                      <a onclick="return confirm('Yakin menghapus data ini?')" class="btn btn-danger" 
                      href="editbasisaturan.php?action=hapus_gejala&idaturan=<?php echo $idaturan; ?>&idgejala=<?php echo $idgejala; ?>">
                      Delete <i class="fas fa-window-close"></i>
                      </a>
                    </td>
                  </tr>
                  <?php
                        }else{
                  ?>
                  <tr>
                    <td align="center"><input type="checkbox" class="check-item" name="<?php echo 'idgejala[]';?>" value="<?php echo $row['idgejala'];?>" ></td>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $row['gejala']; ?></td>
                    <td align="center">
                      <i class="fas fa-window-close"></i></td>
                  </tr>
                  <?php
                      }
                    }
                    $konek_db->close();
                  ?>
                </tbody>
            </table>
          </div>
          <input class="btn btn-primary" type="submit" name="submit" value="Tambah Gejala">
          <a class="btn btn-danger" href="basisaturan.php">Tidak Tambah Gejala</a>
        </div>
      </form>
    </div>
  </div>
</div>

<footer class="footer">
    <div class="container copyright text-center mt-4">
      <p>© <span>Copyright</span> <strong class="px-1 sitename">Tera</strong> <span>All Rights Reserved</span></p>
      <div class="credits">
        Designed by <a href="https://bootstrapmade.com/">Teknologi Informasi UIN Walisongo Semarang</a>
      </div>
    </div>
</footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>


</body>
</html>
