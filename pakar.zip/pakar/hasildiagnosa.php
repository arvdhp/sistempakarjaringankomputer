<?php 
include('koneksi.php');
session_start(); // Pastikan session sudah dimulai
// Mengambil data dari session
$nmpelanggan = $_SESSION['nmpelanggan'];  // Nama pelanggan
$idgejala = $_SESSION['idgejala'];  // Gejala yang dipilih
$gangguan = $_SESSION['gangguan'];  // Data gangguan dan peluang

?>



<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Pakar</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js">

  <!-- Custom CSS -->
  <link rel="stylesheet" href="css/style.css">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Jost:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
</head>
<body>
<header id="header" class="header d-flex align-items-center fixed-top">
  <div class="container-fluid container-xl position-relative d-flex align-items-center">
    <a href="index.php" class="logo d-flex align-items-center me-auto">
      <h1 class="sitename;">Tera</h1>      
    </a>
    <a href="diagnosa.php" class="logo d-flex me-auto">
      <h1 class="sitename;">DIAGNOSA GANGGUAN</h1> 
    </a>
      
    <nav id="navmenu" class="navmenu">
      <ul>
        <li><a href="index.php" class="active">Home</a></li>
        <li><a href="daftargangguan.php">Daftar Gangguan</a></li>
      </ul>
      <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
    </nav>
  </div>
</header>

<div class="row">
    <div class="col-sm-12">
    <div class="card">
    <div class="card-body">
        <form action="" method="POST">
            <div class="card-body">
                <div class="card-body">
                <br><br><br><br><br>
                <center><h1>HASIL KONSULTASI</h1></center></div><br>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">Nama Pelanggan</label>
                            <input type="text" class="form-control" value="<?php echo $nmpelanggan; ?>" name="nama" readonly>
                        </div>

                        <label for=""><br>Gejala-gejala gangguan yang dipilih : <br></label><br>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th width="40px"><center>No.</center></th>
                                    <th width="700px"><center>Nama Gejala</center></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $no = 1;
                                // Menampilkan gejala yang dipilih, data diambil dari session
                                foreach ($idgejala as $gejala_id) {
                                    // Ambil nama gejala dari session atau database jika diperlukan
                                    $sql = "SELECT gejala FROM gejala WHERE idgejala = '$gejala_id'";
                                    $result = $konek_db->query($sql);
                                    $row = $result->fetch_assoc();
                                    ?>
                                    <tr>
                                        <td align="center"><?php echo $no++; ?></td>
                                        <td><?php echo $row['gejala']; ?></td>
                                    </tr>
                                    <?php
                                }
                            ?>
                            </tbody>
                        </table>

                        <label for="">Hasil Konsultasi Gangguan : </label><br>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th width="40px"><center>No.</center></th>
                                    <th width="200px"><center>Nama Gangguan</center></th>
                                    <th width="100px"><center>Persentase</center></th>
                                    <th width="400px"><center>Solusi</center></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $no = 1;
                                // Menampilkan hasil konsultasi gangguan berdasarkan session
                                foreach ($gangguan as $g) {
                                  $sql = "SELECT gangguan, solusi FROM gangguan WHERE idgangguan = '{$g['idgangguan']}'";
                                $result = $konek_db->query($sql);
                                if ($result && $result->num_rows > 0) {
                                  while ($row = $result->fetch_assoc()) {
                                    $solusi_array = explode('-', $row['solusi']);
                            ?>
                                    <tr>
                                        <td align="center"><?php echo $no++; ?></td>
                                        <td><?php echo $row['gangguan']; ?></td>
                                        <td align="center"><?php echo $g['peluang'] . "%"; ?></td>
                                        <td align="justify">
                                        <?php
                                          foreach ($solusi_array as $no => $solusi) {
                                              echo '<p>' . ($no+1) . '. ' . $solusi . '<p/>';
                                          }
                                        ?>
                                        </td>
                                    </tr>
                                    <?php
                                }}}
                                $konek_db->close();
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            </div>
            </div>
        </form>
    </div>
</div>

<footer id="footer" class="footer">
    <div class="container copyright text-center mt-4">
      <p>© <span>Copyright</span> <strong class="px-1 sitename">Tera</strong> <span>All Rights Reserved</span></p>
      <div class="credits">
        Designed by <a href="https://bootstrapmade.com/">Teknologi Informasi UIN Walisongo Semarang</a>
      </div>
    </div>
  </footer>

<!-- Scroll Top -->
<a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Preloader -->
<div id="preloader"></div>

<!-- Vendor JS Files -->
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
<script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>

<!-- Main JS File -->
<script src="assets/js/main.js"></script>

</body>
</html>
