<?php
include('koneksi.php');
session_start();  // Memulai session

date_default_timezone_set("Asia/Jakarta");

if (isset($_POST['proses'])) {
    // Ambil data dari form
    $nmpelanggan = $_POST['nama'];
    $tgl = date("Y/m/d");

    // Menyimpan data pelanggan dan tanggal ke session
    $_SESSION['nmpelanggan'] = $nmpelanggan;
    $_SESSION['tgl'] = $tgl;

    // Simpan data gejala yang dipilih dalam session
    $idgejala = $_POST['idgejala'];  // Ambil array gejala yang dipilih
    $_SESSION['idgejala'] = $idgejala;

    // Proses menghitung peluang gangguan berdasarkan gejala yang dipilih
    $gangguanData = array();  // Array untuk menyimpan data gangguan dan peluang
    $sql = "SELECT * FROM gangguan";
    $result = $konek_db->query($sql);

    while ($row = $result->fetch_assoc()) {
        $idgangguan = $row['idgangguan'];
        $jyes = 0;

        // Hitung jumlah gejala yang terkait dengan gangguan ini
        $sql2 = "SELECT COUNT(idgangguan) AS jml_gejala 
                 FROM basis_aturan 
                 INNER JOIN detail_basis_aturan
                 ON basis_aturan.idaturan = detail_basis_aturan.idaturan
                 WHERE idgangguan = '$idgangguan'";
        $result2 = $konek_db->query($sql2);
        $row2 = $result2->fetch_assoc();
        $jml_gejala = $row2['jml_gejala'];

        // Hitung seberapa banyak gejala yang cocok
        $sql3 = "SELECT basis_aturan.idgangguan, detail_basis_aturan.idgejala
                 FROM basis_aturan 
                 INNER JOIN detail_basis_aturan
                 ON basis_aturan.idaturan = detail_basis_aturan.idaturan
                 WHERE idgangguan = '$idgangguan'";

        $result3 = $konek_db->query($sql3);

        while ($row3 = $result3->fetch_assoc()) {
            $idgejalanya = $row3['idgejala'];

            // Cek apakah gejala ini dipilih oleh pengguna
            if (in_array($idgejalanya, $idgejala)) {
                $jyes += 1;
            }
        }

        // Menghitung peluang gangguan
        if ($jml_gejala > 0) {
            $peluang = round(($jyes / $jml_gejala) * 100, 2);
        } else {
            $peluang = 0;
        }

        // Simpan peluang dan gangguan ke array
        if ($peluang > 0) {
            $gangguanData[] = array('idgangguan' => $idgangguan, 'peluang' => $peluang);
        }
    }

    // Simpan hasil diagnosa ke session
    $_SESSION['gangguan'] = $gangguanData;

    // Redirect ke halaman hasildiagnosa.php setelah proses selesai
    header("Location: hasildiagnosa.php");
    exit();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Pakar</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js">

  <!-- Custom CSS -->
  <link rel="stylesheet" href="css/style.css">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Jost:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
</head>
<body>
<header id="header" class="header d-flex align-items-center fixed-top">
  <div class="container-fluid container-xl position-relative d-flex align-items-center">
    <a href="index.php" class="logo d-flex align-items-center me-auto">
      <h1 class="sitename;">Tera</h1>      
    </a>
    <a href="diagnosa.php" class="logo d-flex me-auto">
      <h1 class="sitename;">DIAGNOSA GANGGUAN</h1> 
    </a>
      
    <nav id="navmenu" class="navmenu">
      <ul>
        <li><a href="index.php" class="active">Home</a></li>
        <li><a href="daftargangguan.php">Daftar Gangguan</a></li>
      </ul>
      <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
    </nav>
  </div>
</header>
<main>
  <div class="row">
    <div class="col-sm-12 mt-5">
    <div class="card">
    <div class="card-body">
      <form action="" method="POST" name="Form" onsubmit="return validasiForm()">
      <div class="card">    
      <div class="card-body">
          <br><br>
          <center><h1>KONSULTASI GANGGUAN</h1></center></div><br>
          <div class="card-body">    
                <div class="form-group mb-3">
                  <label>Nama Pelanggan</label>
                  <input placeholder="Masukkan nama" type="text" class="form-control" name="nama" maxlength="50" required>
                </div>
                <div class="form-grup">
                  <label for="">Pilih gejala-gejala berikut :</label>
                  <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th width="30px"></th>
                        <th width="30px">NO.</th>
                        <th width="700px">Nama Gejala</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                        $no=1;
                        $sql = "SELECT*FROM gejala";
                        $result = $konek_db->query($sql);
                        while($row = $result->fetch_assoc()) 
                        {
                      ?>
                      <tr>
                        <td align="center"><input type="checkbox" class="check-item" name="<?php echo 'idgejala[]'; ?>" value="<?php echo $row['idgejala']; ?>" ></td>
                        <td><?php echo $no++ ?></td>
                        <td><?php echo $row['gejala'];?></td>
                      </tr>
                        <?php
                        }
                          $konek_db->close();
                        ?>
                    </tbody>
                  </table>
                </div>
                <input class="btn btn-primary" type="submit" name="proses" value="Proses">
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</main>
<script type="text/javascript">
    function validasiForm()
    {

        var checkbox=document.getElementsByName('<?php echo 'idgejala[]'; ?>');

        var isChecked=false;

        for(var i=0;i<checkbox.length;i++){
            if(checkbox[i].checked){
                isChecked = true;
                break;
            }
        }


        return true;
    }

</script>

<footer id="footer" class="footer">
    <div class="container copyright text-center mt-4">
      <p>© <span>Copyright</span> <strong class="px-1 sitename">Tera</strong> <span>All Rights Reserved</span></p>
      <div class="credits">
        Designed by <a href="https://bootstrapmade.com/">Teknologi Informasi UIN Walisongo Semarang</a>
      </div>
    </div>
  </footer>

<!-- Scroll Top -->
<a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Preloader -->
<div id="preloader"></div>

<!-- Vendor JS Files -->
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
<script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>

<!-- Main JS File -->
<script src="assets/js/main.js"></script>

</body>
</html>
